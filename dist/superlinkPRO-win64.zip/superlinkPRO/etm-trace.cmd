@echo off
"%~dp0superlinkPRO.exe" --cli %*
exit /b %errorlevel%
