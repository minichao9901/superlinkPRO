superlinkPRO Windows x64 工作台
完整解压后双击 superlinkPRO.exe；保留 runtime、toolbox、cli 目录。
ETM 沿用 KingstVIS Socket，更新前保留 data。
