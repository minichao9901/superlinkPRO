/**
 * 「RTT 转发」页（放在 RTT Viewer 后面）：把 akaLinkPro 探针侧 RTT 桥转出来的 CDC 流当串口看。
 *
 * 为什么单独一页：这块是**纯输出**——数据从探针的 CDC 口出来，页面上没有任何发送，
 * 所以照「串口助手」的接收半边做，砍掉发送框/快捷发送/定时发送/HEX 发送/行尾这些。
 * 保留：端口选择与连接、ASCII/ANSI/HEX 显示、时间戳、暂停、清空、自动滚动、
 *      保存数据、记录到文件（高速采集不丢数）、高速自动关显示（回滞门控）。
 *
 * 串口会话与「串口助手」「终端」**共用同一个**（一个 COM 口只能被一个程序打开，
 * 三个标签是同一路数据的三种看法）—— 数据事件里自己也收一份进本页的接收区。
 * 探针那边的启停/地址在 app/hid/view.js（HID 0x31），本文件不碰 HID。
 */
import { $, seg, setStatus } from '../ui/dom.js';
import { toast } from '../ui/toast.js';
import { store } from '../core/store.js';
import { RxBuffer } from '../core/rxview.js';
import { Counter } from '../core/stats.js';
import { FileRecorder, recordButtonState } from '../core/recorder.js';
import { SerialSession } from '../serial/session.js';
import { isProbeCdcPort } from '../core/cdc-mode.js';
import { DemoPort, demoEnabled } from '../serial/demo.js';
import { bytes as fBytes, rate as fRate, fileStamp, download, stamp as stampOf } from '../core/format.js';
import { AnsiDisplay, BurstGuard, terminalBytes } from '../core/display-stream.js';
import { waitMs } from '../core/pace.js';

const portKey = p => {
  try { const i = p.getInfo?.() || {}; return `${i.usbVendorId ?? 0}-${i.usbProductId ?? 0}`; } catch { return 'x'; }
};

export class RttCdcStreamView {
  constructor(session, { prefix="c", tab="rttcdc", namespace="rttcdc", group="crxmode", owner="rtt" } = {}){
    this.tab=tab; this.namespace=namespace; this.group=group; this.owner=owner;
    this.$=id => $(id === "tab-rttcdc" ? "tab-"+tab : id.replace(/^c-/, prefix+"-"));
    this.key=key => namespace+"."+key;
    this.s = session;
    this.rx = null;
    this.rxc = new Counter();
    this.rec = new FileRecorder();
    this.ansiOn = false;
    this.term = null;
    this.fit = null;
    this._lastWasCR = false;
    this.suppressed = false;
    this.suppManual = false;
    this._bound = false;
    this.burst = new BurstGuard();
  }

  // 门控阈值与串口助手一致（>100KB/s 停渲染，回落到 <50KB/s 才自动恢复）
  static HS_OFF = 100 * 1024;
  static HS_ON = 50 * 1024;

  init(){
    if (this._bound) return;
    this._bound = true;

    this.rx = new RxBuffer(this.$('c-rx'), { maxLines: 4000, maxRaw: 2 * 1024 * 1024,
      isVisible: () => this.$('tab-rttcdc').classList.contains('active') });
    const rxm = store.get(this.key('rxmode'), 'ascii');
    this.rx.setMode(rxm === 'ansi' ? 'ascii' : rxm);      // RxBuffer 只认 ascii/hex，ansi 走 xterm
    this._seg = seg(document.querySelector(`[data-group=${this.group}]`), rxm, v => this._setRxMode(v));
    this._setRxMode(rxm);

    this._chk(this.$('c-ts'), this.key('ts'), v => this.rx.setTimestamps(v, this.$('c-tsabs').checked));
    this._chk(this.$('c-tsabs'), this.key('tsabs'), v => this.rx.setTimestamps(this.$('c-ts').checked, v));
    this._chk(this.$('c-autoscroll'), this.key('autoscroll'), v => this.rx.setAutoscroll(v));
    this._chk(this.$('c-record-ts'), this.key('recordTs'), v => { void v; });
    this._chk(this.$('c-record-auto'), this.key('recordAuto'), v => { void v; });

    store.bind(this.$('c-baud'), this.key('baud'));

    if (!SerialSession.supported()){
      setStatus(this.$('c-err'), '这个浏览器没有 Web Serial（请用桌面版 Chrome / Edge 打开）', 'err');
      this.$('c-open').disabled = true; this.$('c-pick').disabled = true;
    }

    this.$('c-pick').addEventListener('click', () => this.pickPort());
    this.$('c-scan').addEventListener('click', () => this.refreshPorts());
    this.$('c-open').addEventListener('click', () => this.connect());
    this.$('c-close').addEventListener('click', () => this.s.close());
    this.$('c-clear').addEventListener('click', () => { this.rx.clear(); this.ansiDisplay?.clear(); this.term?.clear(); this._lastWasCR = false; });
    this.$('c-save').addEventListener('click', () => this.save());
    this.$('c-record').addEventListener('click', () => this._toggleRecord());
    this.$('c-statclear').addEventListener('click', () => { this.rxc.reset(); this._stats(); });
    this.$('c-err').addEventListener('click', () => {
      if (this.suppressed){ this.suppManual = true; this._setSuppressed(false); }
    });
    this.$('c-pause').addEventListener('click', () => {
      const on = !this.rx.paused;
      this.rx.setPaused(on);
      this.$('c-pause').textContent = on ? '恢复显示' : '暂停显示';
      this.$('c-pause').classList.toggle('primary', on);
      if (!on && this.ansiOn) this._ansiRedraw();
    });

    this.rec.onChange = () => this._recordBtn();
    // 记录期间"本页被切到后台"这类提醒（见 core/recorder.js 里的说明）
    this.rec.onNote = s => toast(s, 'warn', 8000);
    this._recordBtn();

    // ---------------- 会话事件（与助手/终端共用同一个会话） ----------------
    this.s.on('open', ({ opts, info }) => {
      this.$('c-open').disabled = true; this.$('c-close').disabled = false;
      this.$('c-scan').disabled = true; this.$('c-pick').disabled = true; this.$('c-port').disabled = true;
      setStatus(this.$('c-err'), '', null);
      /* 三个页面共用这一个串口会话 → **只对"自己发起的那次"弹提示 / 起自动记录**：
       * 本页专门连探针的 CDC 口，所以在串口助手里开一个普通 UART 时不该冒出
       * 「CDC 波特率不生效」这句（2026-10 代码审查）。连接状态照旧更新。 */
      const mine = opts.owner === this.owner;
      if (mine) toast(`已打开 ${info}（CDC 波特率不生效，随便填）`, 'ok');
      if (mine && this.$('c-record-auto').checked && !this.rec.active) this._autoStartRecord();
      this._stats();
      if (this.owner === 'rtt') globalThis.__tools?.hid?.render();
    });
    this.s.on('close', ({ unexpected }) => {
      this.$('c-open').disabled = false; this.$('c-close').disabled = true;
      this.$('c-scan').disabled = false; this.$('c-pick').disabled = false; this.$('c-port').disabled = false;
      if (unexpected) toast('串口已断开（设备被拔掉或占用）', 'warn');
      this.suppManual = false;
      if (this.suppressed) this._setSuppressed(false);
      this._stopRecord();
      this._stats();
      if (this.owner === 'rtt') globalThis.__tools?.hid?.render();
    });
    this.s.on('data', (b, t) => {
      this.rxc.add(b.length);
      this.rec.push(b, t);                 // 先落文件：接收区有 2MB 上限，记录不吃这个限制
      if (this.burst.add(b.length)) this._highspeedGate(RttCdcStreamView.HS_OFF + 1);
      this.rx.push(b, t);
      if (this.ansiOn && this.term && !this.rx.paused && !this.suppressed) this._ansiFeed(b, t);
    });
    this.s.on('error', e => setStatus(this.$('c-err'), String(e?.message || e), 'err'));

    if (SerialSession.supported()){
      navigator.serial.addEventListener('connect', () => { this.refreshPorts(); });
      navigator.serial.addEventListener('disconnect', () => { this.refreshPorts(); });
    }
    this.refreshPorts();
    setInterval(() => this._stats(), 500);
  }

  onShow(){
    this.rx?.flush(); this.ansiDisplay?.flush();
    if (this.ansiOn){ try { this.fit?.fit(); } catch {} }
    this._stats();
    /**
     * 目标类型是三个页面共用的全局粘性开关（本页 `#h-target` / RTT Viewer `#r-target` /
     * J-Scope `#sc-target`，同一个 store 键 `rtt.target`）。别页刚改过就切过来时，
     * 本页下拉得跟上 —— 显示与探针实际状态不一致正是 2026-10 那条 -2 的起点。
     * （视图是对的：hid 面板由 RttCdcView 持有，这里只借它刷一格界面，不碰探针。）
     */
    if (this.tab === 'rttcdc') globalThis.__tools?.hid?.syncTargetTypeFromStore?.();
  }

  // ---------------- 端口 ----------------
  async refreshPorts(){
    const note = this.$('c-note');
    note.title = '';
    // 演示模式（?demo=serial）：和串口助手一样，用内置假设备，方便演示/自检
    if (demoEnabled()){
      this.ports = [new DemoPort()];
      const sel = this.$('c-port');
      sel.innerHTML = '';
      sel.appendChild(new Option('演示串口', '0'));
      setStatus(this.$('c-note'), '当前使用模拟串口。', null);
      return;
    }
    const sel = this.$('c-port');
    const previous = sel.value === '' ? null : this.ports?.[Number(sel.value)];
    this.ports = await SerialSession.listPorts();
    sel.innerHTML = '';
    if (!this.ports.length){
      sel.appendChild(new Option('未授权串口', ''));
      setStatus(this.$('c-note'), '点「选择…」授权探针的 CDC 端口。', null);
      return;
    }
    this.ports.forEach((p, i) => {
      const alias = store.get('portAlias.' + portKey(p), '');
      sel.appendChild(new Option(`${alias || `串口 ${i + 1}`} · ${SerialSession.describe(p)}`, String(i)));
    });
    const opened = this.s.isOpen ? this.ports.indexOf(this.s.port) : -1;
    const probePorts = this.owner === 'rtt' ? this.ports.filter(isProbeCdcPort) : [];
    const preferred = this.ports.includes(previous) && (this.owner !== 'rtt' || isProbeCdcPort(previous))
      ? previous : probePorts.length === 1 ? probePorts[0] : null;
    const selected = opened >= 0 ? opened : this.ports.indexOf(preferred);
    if (this.owner === 'rtt' && selected < 0) sel.prepend(new Option('请选择探针 CDC', ''));
    sel.value = selected >= 0 ? String(selected) : this.owner === 'rtt' ? '' : '0';
    const summary = this.owner !== 'rtt' ? '' : probePorts.length === 1 ? ' · 已识别探针 CDC'
      : probePorts.length > 1 ? ' · 多个探针 CDC，请选择对应端口' : ' · 未识别探针 CDC';
    setStatus(note, `已授权 ${this.ports.length} 个串口${summary}`);
    note.title = this.ports.map(p => SerialSession.describe(p)).join('\n');
  }

  async pickPort(){
    try {
      const picked = await SerialSession.requestPort();
      await this.refreshPorts();
      const idx = this.ports.indexOf(picked);
      if (idx >= 0) this.$('c-port').value = String(idx);   // 授权后自动跳到新端口（否则像"选了没反应"）
      toast('端口已授权', 'ok');
    } catch (e){
      if (e?.name !== 'NotFoundError') toast('选择端口失败：' + (e?.message || e), 'err');
    }
  }

  async connect(){
    const selected = this.$('c-port').value;
    const port = selected === '' ? null : this.ports?.[Number(selected)];
    if (!port){ toast('请选择已授权的探针 CDC 接收口', 'warn'); return; }
    if (this.owner === 'rtt' && !demoEnabled() && !isProbeCdcPort(port)){
      setStatus(this.$('c-err'), '接收口选错，请选择探针的 CDC 端口', 'err');
      return;
    }
    try {
      await this.s.open(port, {
        baudRate: Number(this.$('c-baud').value) || 115200,
        dataBits: 8, stopBits: 1, parity: 'none', flowControl: 'none',
        owner: this.owner,                // 见 session.open 的说明：只对发起方弹提示/起自动记录
      });
    } catch (e){ setStatus(this.$('c-err'), String(e?.message || e), 'err'); }
  }

  // ---------------- 统计 / 门控 ----------------
  _stats(){
    const now = performance.now();
    const r = this.rxc.rate(now);
    this._highspeedGate(r);
    if (!this.$('tab-rttcdc').classList.contains('active')) return;
    this.$('c-rxbytes').textContent = fBytes(this.rxc.total);
    this.$('c-rxframes').textContent = this.rxc.frames;
    this.$('c-rxrate').textContent = fRate(r);
    this.$('c-buf').textContent = fBytes(this.rx?.bytes ?? 0);
    // 记录/落盘期间按钮要一直刷：字节数、待落盘量都得看得见（见 recorder.js 的说明）
    if (this.rec.active || this.rec.draining) this._recordBtn();
    if (this.rx?.paused) this.$('c-pause').title = `显示已暂停，接收/记录继续；缓冲 ${fBytes(this.rx.bytes)}`;
  }

  _highspeedGate(r){
    if (!this.s.isOpen){
      if (this.suppressed) this._setSuppressed(false);
      this.suppManual = false;
      return;
    }
    if (!this.suppressed && !this.suppManual && r > RttCdcStreamView.HS_OFF) this._setSuppressed(true, r);
    else if (this.suppressed && r < RttCdcStreamView.HS_ON){ this._setSuppressed(false); this.suppManual = false; }
  }

  _setSuppressed(on, r = 0){
    if (this.suppressed === on) return;
    this.suppressed = on;
    if (on){
      this.rx.setDisplayOff(true);
      setStatus(this.$('c-err'), `高速 ${fRate(r)}：渲染已停（收数/记录不受影响）· 点此恢复显示`, 'err');
      this.$('c-err').title = '点击恢复显示。速率仍高于阈值时会再次自动关闭';
    } else {
      // 🚨 先取计数再关抑制：setDisplayOff(false) 会把 suppressedBytes 清零，
      //    先关再读恒为 0 → 这句提示永远不显示（代码审查抓到的，串口助手那边同款）
      const skipped = this.rx.suppressedBytes;
      this.rx.setDisplayOff(false);
      if (this.ansiOn && this.term && skipped > 0){
        this.term.write(`\x1b[90m（高速期间省略了 ${fBytes(skipped)} 的渲染；完整数据用「记录到文件」拿）\x1b[0m\r\n`);
      }
      setStatus(this.$('c-err'), '', null);
      this.$('c-err').title = '';
    }
  }

  // ---------------- 保存 / 记录 ----------------
  /** Finite CLI recording independent of the 2 MiB display history. */
  async captureWindow({seconds=1,maxMiB=32}={}){
    if(!this.s.isOpen)throw Error('先连接接收串口');
    if(this._windowRecording || this._forwardCapture)throw Error('已有窗口记录正在进行');
    if(!Number.isFinite(seconds)||seconds<.1||seconds>30||!Number.isInteger(maxMiB)||maxMiB<1||maxMiB>64)
      throw Error('记录窗口须为0.1..30秒，缓存须为1..64MiB');
    this._windowRecording=true;
    const chunks=[],limit=maxMiB*1024*1024,started=performance.now();
    let bytes=0,observedBytes=0,closed=false,error=null,firstDataAt=null,lastDataAt=null,firstChunkBytes=0;
    const offData=this.s.on('data',b=>{
      if(b.length){const now=performance.now();if(firstDataAt===null){firstDataAt=now;firstChunkBytes=b.length;}lastDataAt=now;}
      observedBytes+=b.length;
      const take=Math.min(b.length,limit-bytes);
      if(take>0){chunks.push(b.slice(0,take));bytes+=take;}
    });
    const offClose=this.s.on('close',()=>{closed=true;});
    const offError=this.s.on('error',e=>{error=e?.message||String(e);});
    try{await new Promise(resolve=>setTimeout(resolve,seconds*1000));}
    finally{offData();offClose();offError();this._windowRecording=false;}
    const elapsed=(performance.now()-started)/1000,name=`${this.owner}-raw-${fileStamp()}.bin`;
    download(name,new Blob(chunks,{type:'application/octet-stream'}));
    const activeSeconds=firstDataAt!==null&&lastDataAt>firstDataAt?(lastDataAt-firstDataAt)/1000:0;
    return {name,bytes,observedBytes,seconds:elapsed,activeSeconds,firstChunkBytes,
      activeBytesPerSecond:activeSeconds?(observedBytes-firstChunkBytes)/activeSeconds:0,complete:bytes>0&&observedBytes===bytes&&!closed&&!error,
      limitExceeded:observedBytes>bytes,portClosed:closed,error,bytesPerSecond:bytes/elapsed};
  }

  /**
   * 已授权**真实**串口的 VID/PID 清单（验收 runner 用来核对「Windows COM ↔ 探针序列号」）。
   *
   * 为什么单列一个方法：串口选择器 `#c-port` 的选项里可能有演示假串口（?demo=serial 的
   * DemoPort，没有 getInfo），Python 端只该按**真实**端口做「同一 VID/PID 唯一匹配」。
   * 只用 SerialPort.getInfo() 的只读信息：不 requestPort（不弹 chooser）、不 open、
   * 不改 this.ports 的选择序号。index 与 `#c-port` 的选项下标一致，Python 直接 set 它。
   */
  forwardPortOptions(){
    if (demoEnabled()) return [];                    // 演示假串口不算授权真实串口
    const ports = Array.isArray(this.ports) ? this.ports : [];
    const out = [];
    ports.forEach((p, index) => {
      let info = null;
      try { info = p?.getInfo?.() || null; } catch { info = null; }
      const vendorId = info?.usbVendorId, productId = info?.usbProductId;
      // 没有 USB 描述符（或读不到）的端口没法做 VID/PID 唯一匹配，不能算进来
      if (!Number.isInteger(vendorId) || !Number.isInteger(productId)) return;
      out.push({ index, vendorId, productId });
    });
    return out;
  }

  /**
   * 验收 runner 的「RTT 转发窗口采集」：START → 收 `seconds` 秒 → STOP → 排空到最终 moved。
   *
   * 和 captureWindow（只按时间窗收数，不碰探针）的区别 —— 这里**要证明转发链路不丢字节**：
   *   ① 串口与 HID 必须**由上游**先选好/打开（本方法不弹 chooser、不 open、不关任何会话）；
   *   ② 探针侧已经有一支桥在跑时**拒绝**（不接管别人的桥）；
   *   ③ 监听在 HidView.start() **之前**挂上，START 之后探针立刻往 CDC 搬字节，晚一步就丢头；
   *   ④ STOP 走生产 HidView.stop()（探针确认 running=false 才返回），然后继续收：
   *      CDC/USB/Web Serial 里还有在途字节 —— 直到浏览器收到的字节数补齐探针报的最终
   *      `moved` 才算完整，超出排空时限如实报 incomplete。
   *
   * 业务异常（启动失败、STOP 未确认、端口断开、限额截断）**不抛**：先用生产 STOP 收尾清理，
   * 再把失败与原始探针状态一起返回，由 runner 落证据。参数/前置条件错误才抛。
   *
   * @returns {{name:string,bytes:number,observedBytes:number,seconds:number,bytesPerSecond:number,
   *   complete:boolean,start:object,stop:object,canRestart:boolean,started:boolean,startError:?string,stopError:?string,
   *   error:?string,drainTimedOut:boolean,limitExceeded:boolean,portClosed:boolean,
   *   limitBytes:number,windowBytes:number,drainBytes:number,drainSeconds:number,drainMs:number,
   *   startSeconds:number,preWindowBytes:number,activeSeconds:number,firstChunkBytes:number,elapsedSeconds:number}}
   */
  async captureForwardWindow({ seconds = 2, maxMiB = 8, drainMs = 5000 } = {}){
    const hid = globalThis.__tools?.hid;
    if (this.tab !== 'rttcdc' || !hid || typeof hid.start !== 'function' || typeof hid.stop !== 'function')
      throw Error('RTT 转发控制面不可用（HidView 未就绪）');
    if (!this.s?.isOpen) throw Error('先连接接收串口：串口与 HID 应由上游选中并打开');
    if (!hid.dev?.connected) throw Error('探针 HID 未连接：上游须先连接探针');
    if (this._forwardCapture || this._windowRecording) throw Error('已有窗口记录正在进行');
    // 探针侧粘性状态：桥在跑 / 启动还在排队 / 别人持有 HID 租约 → 一律不接管
    if (hid.last?.running || hid._bridgeRequested || hid._starting || hid._stopPromise || hid._disconnecting ||
        hid.probeManager?.leases?.has?.('hid'))
      throw Error('探针侧 RTT 桥已在运行或被占用：本接口不接管已有桥，请先停止后再采集');
    if (!Number.isFinite(seconds) || seconds < 0.1 || seconds > 60)
      throw Error('采集窗口须为 0.1..60 秒');
    if (!Number.isInteger(maxMiB) || maxMiB < 1 || maxMiB > 64)
      throw Error('缓存须为 1..64 MiB 的整数');
    if (!Number.isFinite(drainMs) || drainMs < 0 || drainMs > 30000)
      throw Error('排空超时须为 0..30000 毫秒');

    this._forwardCapture = true;
    const limit = maxMiB * 1024 * 1024;
    const startedAt = performance.now();
    const chunks = [];
    let bytes = 0, observedBytes = 0, closed = false, error = null;
    let firstDataAt = null, lastDataAt = null, firstChunkBytes = 0;
    // ① 监听必须先于 START（START 之后探针立刻开始搬字节）
    const offData = this.s.on('data', b => {
      observedBytes += b.length;
      if (b.length){
        const now = performance.now();
        if (firstDataAt === null){ firstDataAt = now; firstChunkBytes = b.length; }
        lastDataAt = now;
      }
      const take = Math.min(b.length, limit - bytes);
      if (take > 0){ chunks.push(b.slice(0, take)); bytes += take; }
    });
    const offClose = this.s.on('close', () => { closed = true; });
    const offError = this.s.on('error', e => { error = e?.message || String(e); });

    let started = false, startError = null, stopError = null;
    let start = null;
    let windowObservedBytes = 0, windowSeconds = 0, startSeconds = 0;
    let windowBaseBytes = 0, windowEndBytes = 0;
    let drainTimedOut = false, stopAt = null;
    try {
      /**
       * 🚨 判定只能按「=== false 才是失败」：生产 HidView.start() 成功时返回 **undefined**
       *    （`_startBridge` 直接把 `_startBridgeNow` 的返回值交出去，成功路径没有 return），
       *    只有失败才返回 false，被其它操作挡住时更是直接 return。所以再补一条硬条件：
       *    探针状态必须真的 `running` —— 否则 START 还在排队/被挡，采集窗口没有意义。
       */
      let startResult = null;
      try { startResult = await hid.start(); }
      catch (e){ startError = e?.message || String(e); startResult = false; }
      started = startResult !== false && hid.last?.running === true;
      if (started) start = {cbAddr: hid.last.cbAddr, channel: hid.last.channel,
        targetType: hid.last.targetType, chunkBytes: hid.last.chunkBytes, swdMhz: hid.last.swdMhz};
      if (!started) startError = startError || hid._statusError
        || (hid.last?.startRc ? `启动 RTT 转发失败（探针返回码 ${hid.last.startRc}）` : '')
        || '探针未确认 START：RTT 桥没进入运行状态';
      if (started){
        // 窗口从「探针确认 running」起算：START 排队/搜控制块的耗时不算进测速窗口
        const windowStartAt = performance.now();
        startSeconds = Math.max(0, (windowStartAt - startedAt) / 1000);
        windowBaseBytes = observedBytes;          // 窗口之前就到的字节不算这一次的实收
        await new Promise(r => setTimeout(r, seconds * 1000));
        windowEndBytes = observedBytes;
        windowObservedBytes = windowEndBytes - windowBaseBytes;
        stopAt = performance.now();
        windowSeconds = (stopAt - windowStartAt) / 1000;
        // ② STOP：生产 HidView.stop() 会等探针真正 running=false 才返回
        try { await hid.stop(); }
        catch (e){ stopError = e?.message || String(e); }
        // ③ 排空：STOP 只是让探针不再搬，CDC/USB/Web Serial 里的在途字节还会继续到
        const movedFinal = Number(hid.last?.moved) || 0;
        const deadline = performance.now() + drainMs;
        while (!stopError && !closed && !error && observedBytes < movedFinal && performance.now() < deadline){
          await waitMs(Math.min(25, Math.max(0, deadline - performance.now())));
        }
        drainTimedOut = movedFinal > 0 && observedBytes < movedFinal;
      } else {
        // 启动失败也要用生产 STOP 收尾：别把半启动的桥留给下一位
        try { await hid.stop(); }
        catch (e){ stopError = e?.message || String(e); }
        windowSeconds = Math.max(0, (performance.now() - startedAt) / 1000);
      }
    } finally {
      offData(); offClose(); offError();
      this._forwardCapture = false;
    }

    const st = hid.last || {};
    const stop = {
      running: typeof st.running === 'boolean' ? st.running : null,
      moved: Number.isSafeInteger(st.moved) ? st.moved : null,
      rdErr: Number.isSafeInteger(st.rdErr) ? st.rdErr : null,
      wrErr: Number.isSafeInteger(st.wrErr) ? st.wrErr : null,
      cbAddr: Number(st.cbAddr) || 0, upAddr: Number(st.upAddr) || 0, channel: Number(st.channel) || 0,
      chunkBytes: Number(st.chunkBytes) || 0, targetType: Number(st.targetType) || 0,
      swdMhz: Number(st.swdMhz) || 0, transfers: Number(st.transfers) || 0, polls: Number(st.polls) || 0,
      emptyRing: Number(st.emptyRing) || 0, dapYield: Number(st.dapYield) || 0, rescans: Number(st.rescans) || 0,
      startRc: st.startRc === undefined ? null : st.startRc, discard: !!st.discard,
    };
    const limitExceeded = observedBytes > bytes;
    const elapsedSeconds = Math.max(0, (performance.now() - startedAt) / 1000);
    const canRestart = stop.running === false && !stopError && !!hid.dev?.connected && !!this.s?.isOpen &&
      globalThis.document?.getElementById?.('h-start')?.disabled !== true;
    const name = `${this.owner}-forward-raw-${fileStamp()}.bin`;
    download(name, new Blob(chunks, { type: 'application/octet-stream' }));
    const complete = bytes > 0 && !limitExceeded && !closed && !error && !startError && canRestart &&
      stop.startRc === 0 && stop.rdErr === 0 && stop.wrErr === 0 && !stop.discard &&
      observedBytes === stop.moved;
    if (!complete){
      const why = startError || stopError || error || (closed ? '串口已断开' : '')
        || (limitExceeded ? `超出 ${maxMiB} MiB 限额` : '')
        || (drainTimedOut ? `STOP 后 ${drainMs} ms 内没收齐最终 moved（已收 ${observedBytes} / 探针 ${stop.moved}）` : '')
        || `收尾计数或引擎状态异常（实收 ${observedBytes}，探针 ${stop.moved}）`;
      this._forwardNote('转发采集不完整：' + why);
    }
    return {
      name, bytes, observedBytes, limitBytes: limit,
      // Throughput ends when STOP is issued. The raw file also includes the tail.
      seconds: windowSeconds, windowBytes: windowObservedBytes,
      bytesPerSecond: windowSeconds > 0 ? windowObservedBytes / windowSeconds : 0,
      startSeconds,
      preWindowBytes: windowBaseBytes,
      drainBytes: observedBytes - windowEndBytes,
      drainSeconds: stopAt === null ? 0 : Math.max(0, (performance.now() - stopAt) / 1000),
      elapsedSeconds, drainMs, drainTimedOut,
      complete, start, stop, canRestart, started,
      startError, stopError, error, portClosed: closed, limitExceeded,
      activeSeconds: firstDataAt !== null && lastDataAt > firstDataAt ? (lastDataAt - firstDataAt) / 1000 : 0,
      firstChunkBytes,
    };
  }

  /** 采集结论要看得见（失败不走 toast：CLI 场景没人点弹窗） */
  _forwardNote(msg){
    try { const el = this.$('c-err'); if (el) setStatus(el, msg, msg ? 'err' : null); } catch { /* 无 DOM 的离线回归 */ }
  }

  save(){
    if (this.rx.empty){ toast('接收区没有数据', 'warn'); return; }
    const name = `${this.owner}-${fileStamp()}.txt`;
    download(name, this.rx.text());
    toast(`已保存 ${name}（${fBytes(this.rx.bytes)}）`, 'ok');
  }

  async _autoStartRecord(){
    try {
      const name = await this.rec.start({ name: this.owner, timestamps: this.$('c-record-ts').checked });
      this._recordBtn();
      toast(`已自动开始记录 → ${name}`, 'ok', 5000);
    } catch (e){
      const why = e?.name === 'NotAllowedError' ? '浏览器要求弹保存框时页面正在响应用户点击' : (e?.message || e);
      toast(`自动记录没启动（${why}）。手动点「记录到文件」即可`, 'warn', 6000);
    }
  }

  async _toggleRecord(){
    if (this.rec.starting || this.rec.draining) return;
    if (this.rec.active || this.rec.needsClose){
      const info = await this.rec.stop();
      this._recordBtn();
      if (info?.error) toast('记录出错：' + (info.error.message || info.error), 'err', 6000);
      else if (info) toast(`已保存 ${info.name}：${fBytes(info.bytes)} / ${info.frames} 段 / ${info.seconds.toFixed(1)} s`, 'ok', 6000);
      return;
    }
    try {
      const name = await this.rec.start({ name: this.owner, timestamps: this.$('c-record-ts').checked });
      this._recordBtn();
      toast(`记录中 → ${name}：Chrome 先写成 ${name}.crswap，点「停止记录」才改名成正式文件（记录中别关页面/刷新）`, 'ok', 8000);
    } catch (e){
      if (e?.name !== 'AbortError') toast('开始记录失败：' + (e?.message || e), 'err', 6000);
    }
  }

  async _stopRecord(){
    if (!this.rec.active && !this.rec.needsClose && !this.rec.starting && !this.rec.draining) return;
    const info = await this.rec.stop();
    this._recordBtn();
    if (info?.error) toast('记录落盘出错：' + (info.error.message || info.error), 'err', 8000);
    else if (info) toast(`已落盘：${info.name}（${fBytes(info.bytes)}）—— .crswap 已改名成正式文件`, 'ok', 7000);
  }

  _recordBtn(){
    const b = this.$('c-record');
    if (!b) return;
    const s = recordButtonState(this.rec);
    b.disabled = this.rec.starting || this.rec.draining;
    b.textContent = s.text;
    b.title = s.title;
    b.classList.toggle('primary', s.primary);
  }

  // ---------------- ANSI（和串口助手同一套） ----------------
  _setRxMode(v){
    store.set(this.key('rxmode'), v);
    this.ansiOn = v === 'ansi';
    this.$('c-term').hidden = !this.ansiOn;
    this.$('c-rx').hidden = this.ansiOn;
    if (this.ansiOn){
      if (!this._ensureAnsiTerm()){ this._seg.set('ascii'); store.set(this.key('rxmode'), 'ascii'); return; }
      this._ansiRedraw();
      try { this.fit?.fit(); } catch {}
    } else {
      this.rx.setMode(v);
    }
  }

  _ensureAnsiTerm(){
    if (this.term) return true;
    if (!window.Terminal){ toast('xterm.js 没加载成功，ANSI 模式不可用', 'err'); return false; }
    this.term = new Terminal({
      fontFamily: '"Cascadia Mono","JetBrains Mono",Consolas,"DejaVu Sans Mono",monospace',
      fontSize: 14, lineHeight: 1.15, cursorBlink: false, scrollback: 5000,
      convertEol: false, allowTransparency: true,
      theme: {
        background: '#0a0f15', foreground: '#e6edf3', cursor: '#58a6ff',
        selectionBackground: '#264f78', black: '#484f58', red: '#ff7b72',
        green: '#3fb950', yellow: '#d29922', blue: '#58a6ff', magenta: '#bc8cff',
        cyan: '#39c5cf', white: '#b1bac4',
      },
    });
    try { this.fit = new FitAddon.FitAddon(); this.term.loadAddon(this.fit); } catch {}
    this.term.open(this.$('c-term'));
    this.ansiDisplay = new AnsiDisplay(this.term, {
      visible: () => this.ansiOn && !this.rx.paused && !this.suppressed && this.$('tab-rttcdc').classList.contains('active'),
      format: (b, t) => this._ansiBytes(b, t),
      onSkip: () => { this._lastWasCR = false; },
      onError: e => setStatus(this.$('c-err'), `终端显示失败：${e.message}；清空后可重试，接收和记录继续`, 'err'),
    });
    this.fit?.fit();
    new ResizeObserver(() => { if (this.ansiOn){ try { this.fit?.fit(); } catch {} } }).observe(this.$('c-term'));
    return true;
  }

  _ansiFeed(bytes, t){
    this.ansiDisplay?.push(bytes, t);
  }

  _ansiBytes(bytes, t){
    const state = { lastWasCR: this._lastWasCR };
    const body = terminalBytes(bytes, state); this._lastWasCR = state.lastWasCR;
    if (!this.rx.timestamps) return body;
    const head = new TextEncoder().encode(`\x1b[90m[${stampOf(t, this.rx.absolute)}]\x1b[0m `);
    const out = new Uint8Array(head.length + body.length); out.set(head); out.set(body, head.length); return out;
  }

  _ansiRedraw(){
    if (!this.term) return;
    this.ansiDisplay?.clear();
    this.term.clear();
    this._lastWasCR = false;
    for (const r of this.rx.raw) this._ansiFeed(r.b, r.t);
  }

  // ---------------- 小工具 ----------------
  _chk(el, key, onChange){
    const apply = () => { const v = store.get(key); if (v !== undefined) el.checked = !!v; };
    apply();
    el.addEventListener('change', () => { store.set(key, el.checked); onChange?.(el.checked); });
    onChange?.(el.checked);
    return el;
  }

  /** 自检用 */
  summary(){
    return {
      open: this.s.isOpen,
      bytes: this.rxc.total,
      frames: this.rxc.frames,
      rate: Math.round(this.rxc.rate()),
      buffered: this.rx.bytes,
      paused: this.rx.paused,
      suppressed: this.suppressed,
      mode: this.ansiOn ? 'ansi' : this.rx.mode,
      recording: this.rec.active,
      recordBytes: this.rec.bytes,
      shown: this.$('c-rx').textContent.length,
    };
  }
}
