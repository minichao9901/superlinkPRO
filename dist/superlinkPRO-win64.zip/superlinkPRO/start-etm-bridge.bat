@echo off
"%~dp0superlinkPRO.exe" %*
exit /b %errorlevel%
