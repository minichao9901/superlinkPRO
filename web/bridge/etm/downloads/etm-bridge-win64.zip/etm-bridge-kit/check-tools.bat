@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0etm-launcher.ps1" -CheckOnly %*
set "RESULT=%ERRORLEVEL%"
echo.
echo ETM bridge exited. Press any key to close.
pause >nul
exit /b %RESULT%
