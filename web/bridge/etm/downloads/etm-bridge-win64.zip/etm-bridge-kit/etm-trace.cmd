@echo off
"%~dp0etm-bridge.exe" --cli %*
exit /b %errorlevel%
